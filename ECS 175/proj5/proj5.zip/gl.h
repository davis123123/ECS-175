#ifndef _GL_H
#define _GL_H

#include <GL/glut.h>
#include "base.h"
#include "object.h"

#endif
