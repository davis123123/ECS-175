#ifndef POLYGON_H
#define POLYGON_H
#include <vector>
#include "Point.h"
using namespace std;

class POLYGON {
public:
	vector<Point> polyP;
	vector<double> knot;
};
#endif