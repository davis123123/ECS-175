
Run instructions:
make
./proj4

First create a curve before any other options!! (Can create multiple)
Q for Beizer
W for Bspline
Then use (a) to start adding points to see the curve
For Bspline default curve is set to straight line, add knots to see the curve (White Line)
Additional options below (selected point is green) (selected curve has points being displayed)
Curve: 
	Next Curve(x)
	Previous Curve(v)
	Remove Current Curve(d)
Point:

	Next Point(n)
	Prev Point(p)
	Add Point(a)
	Remove Current Point(r)
	Insert Point(i)
	Modify current Point(m)

B-spline:
	Increment K(+)
	Decrement K(-)


File saves to `data.txt`
