#ifndef PIXEL_H
#define PIXEL_H

class Pixel {
public:
	int red;
	int green;
	int blue;
};


#endif
